import React, { Component } from 'react';
 import Sidemenu from './Sidemenu'; 
 import Modal from 'react-modal';
 import {Image, Nav, Card, Row, Col} from 'react-bootstrap';


 import Button from 'react-bootstrap/Button';
 const customStyles = {
    content : {
      top                   : '77%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
	  marginRight           : '-50%',
	 
      transform             : 'translate(-100%, -100%)'
    }
  };
 
 class Innermenu extends Component { 
    constructor() {
        super();
     
        this.state = {
          modalIsOpen: false
        };
     
        this.openModal = this.openModal.bind(this);
        this.afterOpenModal = this.afterOpenModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
      }
      openModal() {
        this.setState({modalIsOpen: true});
      }
     
      afterOpenModal() {
        // references are now sync'd and can be accessed.
        this.subtitle.style.color = '#f00';
      }
     
      closeModal() {
        this.setState({modalIsOpen: false});
      }
     render() { 
         
         return (
    
    
<div>
	<Sidemenu/>
	<div class="content-page">
		<div class="content">
			<div class="topbar">
			<Card className="card-body1">
					<Row>
						<Col sm={11} className="page-title">Menu Details</Col>
						<Col sm={1} className="pic">
							<a class="nav-link  nav-user" id="logout" 
                  href="/" role="button" aria-haspopup="false" aria-expanded="false">
								<Image src="assets/logout.png"   />
							</a>
						</Col>
					</Row>
				</Card>
				
				{/* <nav class="navbar-custom">
					<ul class="list-inline float-right mb-0">
						<li class="list-inline-item dropdown notification-list">
							<a class="nav-link  nav-user" id="logout" href="/" role="button" aria-haspopup="false" aria-expanded="false">
								<img src="assets/logout.png" alt="user" class="rounded-circle" />
							</a>
						</li>
					</ul>
					<ul class="list-inline menu-left mb-0">
						<li class="list-inline-item">
							<button type="button" class="button-menu-mobile open-left waves-effect">
								<i class="fa fa-bars"></i>
							</button>
						</li>
						<li class="hide-phone list-inline-item app-search">
							<h3 class="page-title">Menu Details</h3>
						</li>
					</ul>
					<div class="clearfix"></div>
				</nav> */}
				<div class="page-content-wrapper">
					<div class="container-fluid">
						<div class="row">
							<div class="col-lg-12">
								<div class="card m-b-30">
									<div class="card-body">
										<div class="row">
                                          
											<div class="col-sm-10">
										
										
											<button className="btnclr" onClick={this.openModal}>Add Item</button>
											<Modal 
                                            isOpen={this.state.modalIsOpen}
                                             onAfterOpen={this.afterOpenModal}
                                               onRequestClose={this.closeModal}
                                                 style={customStyles}
                                                   contentLabel="Example Modal"
                                                >
												<h5 className="modalmenu" ref={subtitle => this.subtitle = subtitle}>Add your Menu Details</h5>
												<form >
													<div class="form-group row">
														<div class="row">
															<div class="col-sm-6">
																<div class="col-sm-12">
																	<input type="text" class="form-control" placeholder="Enter your Item Name" />
																</div>
															</div>
															<div class="col-sm-6">
																<div class="col-sm-12">
																	<input type="file" class="form-control" />
																</div>
															</div>
														</div>
													</div>
													<div class="form-group row">
														<label class="col-sm-2 col-form-label">Item Description</label>
														<div class="col-sm-10">
															<textarea rows="5" cols="5" class="form-control" placeholder="Item description"></textarea>
														</div>
													</div>
													<div class="form-group row">
														<label class="col-sm-2"></label>
														<div class="col-sm-10">
															<button type="submit"  onClick={this.closeModal}  class="btn btn-primary m-b-0">
																<a href="#" class="js-modal-close">Submit</a>
															</button>
														</div>
													</div>
												</form>
											</Modal>
                                 
                                                {/* 
											<div class="col-sm-10">
												<button type="submit" class="btn btn-primary m-b-0">
													<a class="js-open-modal" href="#" data-modal-id="popup"> Add Item </a>
												</button>
												<div id="popup" class="modal-box">
													<header>
														<a href="#" class="js-modal-close close">×</a>
														<form>
															<div class="form-group row">
																<label class="col-sm-2 col-form-label">Item Name</label>
																<div class="col-sm-10">
																	<input type="text" class="form-control" placeholder="Enter your Item Name" />
																</div>
															</div>
															<div class="form-group row">
																<label class="col-sm-2 col-form-label">Image Location</label>
																<div class="col-sm-10">
																	<input type="file" class="form-control" />
																</div>
															</div>
															<div class="form-group row">
																<label class="col-sm-2 col-form-label">Item Description</label>
																<div class="col-sm-10">
																	<textarea rows="5" cols="5" class="form-control" placeholder="Item description"></textarea>
																</div>
															</div>
															<div class="form-group row">
																<label class="col-sm-2"></label>
																<div class="col-sm-10">
																	<button type="submit" class="btn btn-primary m-b-0">
																		<a href="#" class="js-modal-close">Submit</a>
																	</button>
																</div>
															</div>
														</form>
													</header>
												</div>
											</div> */}
                                            </div>
                                           
                                                
											<div class="col-sm-2 leftalingn">
												<input type="text" id="myInput" onkeyup="myFunction()" placeholder="  Search  Id" />
											</div>
										</div>
                                       
										<div class=" overflow-div">
											<div id="o-message"></div>
											<div id="alert_message"></div>
										 <table id="menuTable" class="table table-bordered">
												<thead>
													<tr class="header tableclr">
														<th>Item ID</th>
														<th>Profile Pic</th>
														<th>Item Name</th>
														<th>Description</th>
														<th>Created Date</th>
														<th>Actions</th>
													</tr>
												</thead>
												<tbody>
													<tr class="header">
														<td></td>
														<td>
															<div class="image-upload">
																<label for="file-input">
																	<img src="https://lh4.googleusercontent.com/proxy/6aRHrlzTXMVt8q-4m63sV3BmvU_bKxH0QDBlQpeujeo6gYVI3rJWoBBNa_OsshR4EoFFYpRXofUkIo20JeVW_MozxDLBPCNqUOwdpfYpsRMRv3f8BtczgszCnEUoKnhPrw" />
																</label>
																<input id="file-input" type="file" />
															</div>
														</td>
														<td></td>
														<td></td>
														<td></td>
														<td>
															<a class="add" title="Add" data-toggle="tooltip">
																<i class="material-icons">&#xE03B;</i>
															</a>
															<a class="edit" title="Edit" data-toggle="tooltip">
																<i class="material-icons">&#xE254;</i>
															</a>
														</td>
													</tr>
												</tbody>
											</table> 
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="footer">
        
                    © 2020 - Developed and Maintained by LaakBot
        
                </div>
	</div>
</div>
        ); } } export default Innermenu;